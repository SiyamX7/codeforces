#!/bin/bash
# StressTest wrapper for Sublime + Kitty

# Permanent Kitty window title
KITTY_TITLE="StressTest"

# Move to the root script folder
cd "$(dirname "$0")"

# Check if a kitty window with this title exists
if ! kitty @ ls | grep -q "$KITTY_TITLE"; then
    # Launch kitty and tell it to enter 'bag' and run the script
    kitty --title "$KITTY_TITLE" bash -c "cd bag && ./stress.sh; exec bash" &
else
    # Send command to existing window to enter 'bag' and run
    kitty @ send-text --match title:"$KITTY_TITLE" "cd bag && ./stress.sh\n"
fi