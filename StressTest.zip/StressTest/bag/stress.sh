#!/bin/bash
# Move to the directory where this script is located (the 'bag' folder)
cd "$(dirname "$0")"

# Compile the codes inside 'bag'
g++ -std=c++17 gen.cpp -o gen
g++ -std=c++17 brute.cpp -o brute
g++ -std=c++17 solution.cpp -o sol

for ((i=1;i<=1000;i++)); do
    ./gen > test.in
    ./brute < test.in > out_brute.txt
    ./sol < test.in > out_sol.txt

    if ! diff out_brute.txt out_sol.txt >/dev/null; then
        echo "❌ Wrong Answer at test $i"
        echo "Input:"; cat test.in
        echo "Brute Output:"; cat out_brute.txt
        echo "Your Output:"; cat out_sol.txt
        exit 0
    fi
    echo "✅ Passed test $i"
done